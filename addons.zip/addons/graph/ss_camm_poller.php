<?php

$no_http_headers = true;

/* display ALL errors */
error_reporting(E_ALL);

if (!isset($called_by_script_server)) {
	include_once(dirname(__FILE__) . "/../include/global.php");

 $cacti_camm_components["snmptt"]=(read_config_option("camm_use_snmptt", true)==1 ? true : false);
 $cacti_camm_components["syslog"]=(read_config_option("camm_use_syslog", true)==1 ? true : false);
 $cacti_camm_components["camm_syslog_db_name"] = read_config_option("camm_syslog_db_name");

	print call_user_func("ss_camm_poller_time") . "\n";
	print call_user_func("ss_camm_poller_tree_time") . "\n";
	print call_user_func("ss_camm_poller_syslog_rows") . "\n";
	print call_user_func("ss_camm_poller_snmptt_rows") . "\n";
	print call_user_func("ss_camm_poller_unksnmptt_rows") . "\n";
}


 

function ss_camm_poller_time() {
	global $database_username;
	global $database_password;
	global $database_hostname;
	global $database_default;
	global $database_type;

/*	db_connect_real($database_hostname, $database_username, $database_password, $database_default, $database_type);*/
	$stats = db_fetch_cell("select value from settings where name='camm_stats_time_general';");

	return trim($stats);
}

function ss_camm_poller_tree_time() {
	global $database_username;
	global $database_password;
	global $database_hostname;
	global $database_default;
	global $database_type;

/*	db_connect_real($database_hostname, $database_username, $database_password, $database_default, $database_type);*/
	$stats = db_fetch_assoc("select value from settings where name in ('camm_stats_snmptt_tree','camm_stats_syslog_tree');");
  if (!isset($stats["0"]["value"])) $stats["0"]["value"] = 'TreesnmpttTime:0';
  if (!isset($stats["1"]["value"])) $stats["1"]["value"] = 'TreesyslogTime:0';

  $stats["0"]["v"] = trim(substr(strrchr($stats["0"]["value"],':'),1));
  $stats["1"]["v"] = trim(substr(strrchr($stats["1"]["value"],':'),1));
  
 $stats["2"] = ($stats["0"]["v"] + $stats["1"]["v"]);
  
	return trim(trim($stats["0"]["value"]) . " "  . trim($stats["1"]["value"]) . " t1:" . $stats["2"]);
}

function ss_camm_poller_syslog_rows() {
	global $database_username;
	global $database_password;
	global $database_hostname;
	global $database_default;
	global $database_type;
	global $cacti_camm_components;

//when start from ss - we don't process start part of this file
if (!isset($cacti_camm_components["syslog"])) {
 $cacti_camm_components["syslog"]=(read_config_option("camm_use_syslog", true)==1 ? true : false);
 $cacti_camm_components["camm_syslog_db_name"] = read_config_option("camm_syslog_db_name");
}

if ($cacti_camm_components["syslog"]) {
/*	db_connect_real($database_hostname, $database_username, $database_password, $database_default, $database_type);*/
	$stats = db_fetch_assoc("select value from settings where name in ('camm_sys_max_row_all','camm_stats','camm_stats_ruledel_syslog') order by name desc;");
	$stats["2"]["value"] = explode(' ',$stats["2"]["value"]);
	$stats["2"]["value"] = $stats["2"]["value"]["2"];
  $count_syslogs = db_fetch_cell("select count(*) from `" . $cacti_camm_components["camm_syslog_db_name"] . "`.`plugin_camm_syslog`;");

  $syslog_purge_delay = read_config_option("camm_sys_delay_purge_day");
  if ($syslog_purge_delay > 0) {
    $count_syslog_old = db_fetch_cell("select count(*) from `" . $cacti_camm_components["camm_syslog_db_name"] . "`.`plugin_camm_syslog` where ( date(`sys_date`) < date(ADDDATE(date(NOW()), INTERVAL -" . $syslog_purge_delay . " DAY)));");
  }else{
    $count_syslog_old = 0;
  }
  $t1=$count_syslogs-$count_syslog_old;
	return trim("camm_sys_max_row_all:" . $stats["0"]["value"] . " "  . $stats["2"]["value"] . " del_rule:"  . abs($stats["1"]["value"]) . " count_syslogs:" . $count_syslogs . " count_syslog_old:" . $count_syslog_old . " t1:" . $t1);

}else{
  return trim("camm_sys_max_row_all:0 del_sys_messages:0 del_rule:0 count_syslogs:0 count_syslog_old:0 t1:0");
}
	
}



function ss_camm_poller_snmptt_rows() {
	global $database_username;
	global $database_password;
	global $database_hostname;
	global $database_default;
	global $database_type;
	global $cacti_camm_components;

//when start from ss - we don't process start part of this file
if (!isset($cacti_camm_components["snmptt"])) {
  $cacti_camm_components["snmptt"]=(read_config_option("camm_use_snmptt", true)==1 ? true : false);
}

if ($cacti_camm_components["snmptt"]) {
/*	db_connect_real($database_hostname, $database_username, $database_password, $database_default, $database_type);*/
	$stats = db_fetch_assoc("select value from settings where name in ('camm_snmptt_max_row_all','camm_stats', 'camm_stats_ruledel_snmptt') order by name;");
	$stats["1"]["value"] = explode(' ',$stats["1"]["value"]);
	$stats["1"]["value"] = $stats["1"]["value"]["0"];
  $count_snmptt = db_fetch_cell("select count(*) from `plugin_camm_snmptt`;");
  $snmptt_purge_delay = read_config_option("camm_snmptt_delay_purge_day");
  if ($snmptt_purge_delay > 0) {
    $count_snmptt_old = db_fetch_cell("select count(*) from `plugin_camm_snmptt` where ( date(`traptime`) < date(ADDDATE(date(NOW()), INTERVAL -" . $snmptt_purge_delay . " DAY)));");
  }else{
    $count_snmptt_old = 0;
  }
  $t1=$count_snmptt-$count_snmptt_old;


	return trim("camm_snmptt_max_row_all:" . $stats["0"]["value"] . " "  . $stats["1"]["value"] . " del_rule:"  . abs($stats["2"]["value"]) . " count_snmptt:" . $count_snmptt . " count_snmptt_old:" . $count_snmptt_old . " t1:" . $t1);

}else{
  return trim("camm_snmptt_max_row_all:0 del_traps:0 del_rule:0 count_snmptt:0 count_snmptt_old:0 t1:0");
}

}


function ss_camm_poller_unksnmptt_rows() {
	global $database_username;
	global $database_password;
	global $database_hostname;
	global $database_default;
	global $database_type;
	global $cacti_camm_components;

//when start from ss - we don't process start part of this file
if (!isset($cacti_camm_components["snmptt"])) {
  $cacti_camm_components["snmptt"]=(read_config_option("camm_use_snmptt", true)==1 ? true : false);
}

if ($cacti_camm_components["snmptt"]) {
/*	db_connect_real($database_hostname, $database_username, $database_password, $database_default, $database_type);*/
	$stats = db_fetch_assoc("select value from settings where name in ('camm_snmptt_max_row_all','camm_stats') order by name;");
	$stats["1"]["value"] = explode(' ',$stats["1"]["value"]);
	$stats["1"]["value"] = $stats["1"]["value"]["1"];
  $count_snmptt = db_fetch_cell("select count(*) from `plugin_camm_snmptt_unk`;");
  $snmptt_purge_delay = read_config_option("camm_snmptt_delay_purge_day");
  if ($snmptt_purge_delay > 0) {
    $count_snmptt_old = db_fetch_cell("select count(*) from `plugin_camm_snmptt_unk` where ( date(`traptime`) < date(ADDDATE(date(NOW()), INTERVAL -" . $snmptt_purge_delay . " DAY)));");
  }else{
    $count_snmptt_old = 0;
  }
  $t1=$count_snmptt-$count_snmptt_old;
  
	return trim("camm_unksnmptt_max_row_all:" . $stats["0"]["value"] . " "  . $stats["1"]["value"] . " count_unksnmptt:" . $count_snmptt . " count_unksnmptt_old:" . $count_snmptt_old . " t1:" . $t1);

}else{
  return trim("camm_unksnmptt_max_row_all:0 del_unk_traps:0 count_unksnmptt:0 count_unksnmptt_old:0 t1:0");
}

}

?>
